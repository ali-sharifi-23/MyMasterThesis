% define a continuous function
f = '4*sin(2*pi*t)';
% plot a figure
ezplot(f); 
